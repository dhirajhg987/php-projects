<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Access-Control-Allow-Methods,Content-Type,Authorization');

$data = json_decode(file_get_contents("php://input"), true);

$sid = $data['sid'];
$sname = $data['sname'];
$semail = $data['semail'];
$saddress = $data['saddress'];

include_once 'connection.php';

$result = "UPDATE student SET name = '{$sname}', email = '{$semail}', address = '{$saddress}' WHERE id = '{$sid}'";

if(mysqli_query($conn , $result))
{
	echo json_encode(array('message' => 'Record Updated Successfully', 'status' => true));
}
else
{
	echo json_encode(array('message' => 'Record Not Updated', 'status' => false));
}
?>