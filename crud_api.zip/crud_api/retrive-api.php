<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include_once 'connection.php';

$result = mysqli_query($conn , "SELECT * FROM student");

if(mysqli_num_rows($result)>0)
{
	$row = mysqli_fetch_all($result, MYSQLI_ASSOC);	
	echo json_encode($row);
}
else
{
	echo json_encode(array('message' => 'No record found', 'status' => false));
}
?>