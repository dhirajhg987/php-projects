<?php

$conn = mysqli_connect("localhost","root","","api_database") or die("Error :".mysqli_error());

?>