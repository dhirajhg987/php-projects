<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Access-Control-Allow-Methods,Content-Type,Authorization');

$data = json_decode(file_get_contents("php://input"), true);

$sname = $data['sname'];
$semail = $data['semail'];
$saddress = $data['saddress'];

include_once 'connection.php';

$sql = "INSERT INTO student(name,email,address) VALUES ('$sname','$semail','$saddress')";

if(mysqli_query($conn, $sql))
{
	echo json_encode(array('message' => 'Record Inserted Successful', 'status' => true));
}
else
{
	echo json_encode(array('message' => 'Record Not Inserted', 'status' => false));
}

?>